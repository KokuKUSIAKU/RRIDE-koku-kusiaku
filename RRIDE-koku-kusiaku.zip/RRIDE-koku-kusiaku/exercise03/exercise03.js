// Add your custom js here
$(".RevealCard-header").click(function(e){
  $(e.target).next().toggleClass("RevealCard-list-display");
  $(e.target).toggleClass("RevealCard-markup");
})
